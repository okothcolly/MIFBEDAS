from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, MonthlyReport
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("MiFBeDAS access", {"fields": ("role", "subcounty")}),)
    list_display = ("username", "email", "role", "subcounty", "is_active", "is_staff")
@admin.register(MonthlyReport)
class MonthlyReportAdmin(admin.ModelAdmin):
    list_display = ("subcounty", "month", "year", "officer", "status", "updated_at")
    list_filter = ("subcounty", "month", "year", "status")
    search_fields = ("subcounty", "officer__username")
