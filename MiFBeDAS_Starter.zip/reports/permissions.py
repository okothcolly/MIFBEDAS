from rest_framework.permissions import BasePermission, SAFE_METHODS
class CanAccessReport(BasePermission):
    def has_object_permission(self, request, view, obj):
        role = getattr(request.user, "role", "")
        if role in ("ADMIN", "DIRECTOR", "COUNTY_REVIEWER"):
            return True
        return obj.officer_id == request.user.id or obj.subcounty == getattr(request.user, "subcounty", "")
class IsReviewerOrAdmin(BasePermission):
    def has_permission(self, request, view):
        return getattr(request.user, "role", "") in ("ADMIN", "DIRECTOR", "COUNTY_REVIEWER")
