from rest_framework import serializers
from .models import MonthlyReport
class MonthlyReportSerializer(serializers.ModelSerializer):
    officer_username = serializers.CharField(source="officer.username", read_only=True)
    class Meta:
        model = MonthlyReport
        fields = "__all__"
        read_only_fields = ["officer", "reviewer", "submitted_at", "reviewed_at", "created_at", "updated_at", "status", "review_comment"]
    def validate_month(self, value):
        if value < 1 or value > 12:
            raise serializers.ValidationError("Month must be between 1 and 12.")
        return value
    def validate_year(self, value):
        if value < 2000 or value > 2100:
            raise serializers.ValidationError("Enter a valid reporting year.")
        return value
