import csv
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import MonthlyReport
from .serializers import MonthlyReportSerializer
from .permissions import CanAccessReport, IsReviewerOrAdmin

@api_view(["GET"])
@permission_classes([])
def health(request):
    return Response({"status": "ok", "service": "MiFBeDAS API starter"})

class MonthlyReportViewSet(viewsets.ModelViewSet):
    serializer_class = MonthlyReportSerializer
    permission_classes = [IsAuthenticated, CanAccessReport]
    def get_queryset(self):
        u = self.request.user
        qs = MonthlyReport.objects.all()
        if getattr(u, "role", "") in ("ADMIN", "DIRECTOR", "COUNTY_REVIEWER"):
            return qs
        return qs.filter(subcounty=getattr(u, "subcounty", ""), officer=u)
    def perform_create(self, serializer):
        serializer.save(officer=self.request.user, subcounty=getattr(self.request.user, "subcounty", ""))
    @action(detail=True, methods=["post"])
    def submit(self, request, pk=None):
        report = self.get_object()
        if report.status not in ("DRAFT", "RETURNED"):
            return Response({"detail": "Only drafts or returned reports can be submitted."}, status=400)
        report.status = "SUBMITTED"
        report.submitted_at = timezone.now()
        report.save()
        return Response(self.get_serializer(report).data)
    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated, IsReviewerOrAdmin])
    def approve(self, request, pk=None):
        report = self.get_object()
        if report.status != "SUBMITTED":
            return Response({"detail": "Only submitted reports can be approved."}, status=400)
        report.status = "APPROVED"
        report.reviewer = request.user
        report.review_comment = request.data.get("comment", "")
        report.reviewed_at = timezone.now()
        report.save()
        return Response(self.get_serializer(report).data)
    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated, IsReviewerOrAdmin])
    def return_for_correction(self, request, pk=None):
        report = self.get_object()
        if report.status != "SUBMITTED":
            return Response({"detail": "Only submitted reports can be returned."}, status=400)
        report.status = "RETURNED"
        report.reviewer = request.user
        report.review_comment = request.data.get("comment", "")
        report.reviewed_at = timezone.now()
        report.save()
        return Response(self.get_serializer(report).data)

@api_view(["GET"])
@permission_classes([IsAuthenticated, IsReviewerOrAdmin])
def export_csv(request):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="mifbedas_monthly_reports.csv"'
    writer = csv.writer(response)
    writer.writerow(["Sub-county", "Month", "Year", "Officer", "Status", "Activities", "Achievements", "Challenges", "Work plan"])
    for r in MonthlyReport.objects.all().select_related("officer"):
        writer.writerow([r.subcounty, r.month, r.year, r.officer.username, r.status, r.activities, r.achievements, r.challenges, r.workplan])
    return response
