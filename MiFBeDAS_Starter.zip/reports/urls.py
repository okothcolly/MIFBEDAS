from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MonthlyReportViewSet, export_csv
router = DefaultRouter()
router.register("monthly-reports", MonthlyReportViewSet, basename="monthly-report")
urlpatterns = [path("", include(router.urls)), path("reports/export.csv", export_csv, name="export-csv")]
