from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    class Role(models.TextChoices):
        SUBCOUNTY_OFFICER = "SUBCOUNTY_OFFICER", "Sub-county Officer"
        COUNTY_REVIEWER = "COUNTY_REVIEWER", "County Reviewer"
        DIRECTOR = "DIRECTOR", "Director"
        ADMIN = "ADMIN", "System Administrator"
    role = models.CharField(max_length=30, choices=Role.choices, default=Role.SUBCOUNTY_OFFICER)
    subcounty = models.CharField(max_length=80, blank=True)

class MonthlyReport(models.Model):
    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        SUBMITTED = "SUBMITTED", "Submitted"
        RETURNED = "RETURNED", "Returned for correction"
        APPROVED = "APPROVED", "Approved"
    subcounty = models.CharField(max_length=80)
    month = models.PositiveSmallIntegerField()
    year = models.PositiveSmallIntegerField()
    officer = models.ForeignKey(User, on_delete=models.PROTECT, related_name="monthly_reports")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    summary = models.JSONField(default=dict, blank=True)
    activities = models.TextField(blank=True)
    achievements = models.TextField(blank=True)
    challenges = models.TextField(blank=True)
    workplan = models.TextField(blank=True)
    evidence_reference = models.CharField(max_length=500, blank=True)
    reviewer = models.ForeignKey(User, null=True, blank=True, on_delete=models.PROTECT, related_name="reviewed_reports")
    review_comment = models.TextField(blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["subcounty", "month", "year"], name="unique_subcounty_monthly_report")]
        ordering = ["-year", "-month", "subcounty"]
    def __str__(self):
        return f"{self.subcounty} — {self.month}/{self.year} ({self.status})"
