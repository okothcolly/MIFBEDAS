# MiFBeDAS Online Starter — County Reporting

This is a developer starter project for the next stage of MiFBeDAS. It is **not yet a deployed or production-ready service**.

## What is included
- Django REST Framework backend scaffold
- PostgreSQL configuration through environment variables
- Custom user roles: Sub-county Officer, County Reviewer, Director, Administrator
- Monthly report model and draft/submit/review/approve/return workflow endpoints
- CSV report export endpoint
- Deployment notes and an environment-variable template

## Before use
A developer must install dependencies, run migrations, create the initial administrator, test permissions, and deploy to an approved hosting provider. Do not put real or confidential county data into an unreviewed instance.

## Local development (for a developer)
1. Install Python 3.12+ and PostgreSQL, or use the included Docker Compose file.
2. Copy `.env.example` to `.env` and set a strong `DJANGO_SECRET_KEY` and database password.
3. Build and start: `docker compose up --build`
4. In a second terminal, create an administrator: `docker compose exec web python manage.py createsuperuser`
5. Open `http://localhost:8000/admin/` for Django admin and `http://localhost:8000/api/health/` for the health endpoint.

The current scaffold is an implementation starting point, not a guarantee that all requirements from the county workbook have been implemented. Detailed workbook fields, validation rules, indicator calculations, multi-factor authentication, production security, and deployment must be completed and tested.
